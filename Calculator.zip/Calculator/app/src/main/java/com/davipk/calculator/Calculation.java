package com.davipk.calculator;

import android.util.Pair;



import java.util.ArrayList;
import java.util.List;


/**
 * This class handles everything in regards to basic calculator operations
 */
public class Calculation {

    private CalculationResult calculationResult;
    private static String currentExpression;
    private List<Pair<String, String>> operators = new ArrayList<>();

    interface CalculationResult{
        void onExpressionChanged(String result, String operation, boolean successful);
    }

    public void setCalculationResultListener(CalculationResult calculationResult){
        this.calculationResult = calculationResult;
        currentExpression = "0";
        refreshExpression();
    }

    public void refreshExpression(){
        calculationResult.onExpressionChanged(currentExpression, displayOperatorExpression(), true);
    }

    public void refreshExpression(String error){
        calculationResult.onExpressionChanged(error, displayOperatorExpression(), false);
    }

    /**
     * Deletes the last character of current expression if non-zero.
     */
    public void backspace(){
        if(currentExpression.length() != 1){
            currentExpression = currentExpression.substring(0, currentExpression.length() - 1);
        } else {
            currentExpression = "0";
        }
        refreshExpression();
    }

    /**
     * Deletes the entire current expression if non-zero.
     */
    public void clear(){
        if(!currentExpression.equals("0")){
            currentExpression = "0";
        }
        refreshExpression();
    }

    /**
     * Deletes the current and operator expression entry.
     */
    public void clearEntry(){
        currentExpression = "0";
        operators.clear();
        refreshExpression();
    }

    /**
     * Appends the number to currentExpression upon getting clicked.
     * @param number the character that is getting added
     */
    public void addNumber(String number){
        if(currentExpression.length() >= 16){
            refreshExpression("Cannot exceed 16 digits.");
        } else {
            if(currentExpression.equals("0")){
                currentExpression = "";
            }
            currentExpression += number;
            refreshExpression();
        }
    }

    /**
     * Adds decimal places if not present upon getting clicked.
     */
    public void addDecimal(){
        if(!currentExpression.contains(".")){
            currentExpression += ".";
        }
        refreshExpression();
    }

    /**
     * Flips positive/negative signs of current expression.
     */
    public void negate(){
        if(currentExpression.equals("0")){
            return;
        }
        String newExpression = "";
        if(currentExpression.contains("-")){
            for(Character c : currentExpression.toCharArray()){
                if(c != '-'){
                    newExpression += c;
                }
            }
        } else {
            newExpression = "-" + currentExpression;
        }
        currentExpression = newExpression;
        refreshExpression();
    }

    /**
     * Performs various operations depending on what has been clicked.
     * @param operator distinguishes what type of operation it is
     */
    public void addOperation(String operator){
        String tempExpression = currentExpression;
        if(tempExpression.equals("0.")){
            tempExpression = "0";
        }
        if(!operators.isEmpty()){
            if(tempExpression.equals("0")){
                tempExpression = operators.get(operators.size() - 1).second;
                operators.remove(operators.size() - 1);
            }
        }
        operators.add(new Pair<String, String>(operator, tempExpression));
        refreshExpression();
        //TODO:updare expression here after evaluate method.
        currentExpression = "0";
    }

    /**
     * Returns the current operator expression to the display
     * @return operator expression
     */
    public String displayOperatorExpression(){
        if(operators.isEmpty()){
            return "";
        } else {
            String output = "";
            for(Pair<String, String> operator : operators){
                if(operator.first.equals("√") || operator.first.equals("sqr") || operator.first.equals("inv")){
                    output += " " + operator.first + "(" + operator.second + ") +";
                } else {
                    output += " " + operator.second + " " + operator.first;
                }
            }
            return output;
        }
    }

}
